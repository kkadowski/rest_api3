from src import create_app


application = create_app()
